
	function quiz (){
		//Форма
		const 	quizForm = document.getElementById('quiz-form');
		if (quizForm) {
			const 	questions = [
				{
					name: 'Фундамент',
					answer:false,
					level: [
						{ 
							name: 'Под дом',
							answer:false,
							level: [
								{
									name: 'Кирпич',
									answer:'М250 - М300',
								},
								{
									name: 'Керамзитоблок',
									answer:'М200 - М250',
								},
								{
									name: 'Газобетон',
									answer:'М200 - М250',
								},
								{
									name: 'SIP',
									answer:'М200 - М250',
								},
								{
									name: 'Каркасный',
									answer:'М200 - М250',
								},
							]
						},
						{ 
							name: 'Баню',
							answer:'М200 - М250',
						},
						{ 
							name: 'Фундаментная плита под дом',
							answer:'М300 - М350',
						},
						{ 
							name: 'Фундаментная плита под баню',
							answer:'М300 - М350',
						},
					],
				},
				{
					name: 'Сваи под фундамент',
					answer:'М200 - М250',
				},
				{
					name: 'Плита перекрытия этажа',
					answer:'М250 - М300',
				},
				{
					name: 'Лестница',
					answer:'М300',
				},
				{
					name: 'Армопояс',
					answer:'М250',
				},
				{
					name: 'Отмостка фундамента',
					answer:'М200 - М250',
				},
				{
					name: 'Стяжка на пол',
					answer:'Пескобетон (ПБМ100 - ПБМ250)',
				},
				{
					name: 'Дорожки на учакстке',
					answer:'М250 - М300',
				},
				{
					name: 'Столбы под забор',
					answer:'М200 - М250',
				},

			];

			//Навигация формы
			const 	quizNav = quizForm.querySelector('.quiz-nav');
			
			//Контейнер чекбоксов
			const 	questionСontainer = quizForm.querySelector('.question-container');

			var indexOfPage = 0; //Индекс страниц
			var arrPageHistory = []; //Массивы всех переходов
				arrPageHistory[0] = questions.slice(); //1 страница
			var renderPage; // Содержимое страницы


			const render = (item_num) => {

				let quizNavLi = quizForm.querySelectorAll('.quiz-nav li');
				
				if (indexOfPage != 0) {
					if (arrPageHistory[indexOfPage-1][item_num].answer != false) { //Ответ
						
						renderPage = `<div class="result">
										 <p>Вам нужна марка:<br> ${arrPageHistory[indexOfPage-1][item_num].answer}</p>
										 <div class="btn-red update">Рассчитать</div>
									  </div>`;

						//Чистим активные классы у навигации
						for (let i = 0; i < quizNavLi.length; i++) {quizNavLi[i].classList.remove('active');}
						//Добавляем навигацию
						quizNav.insertAdjacentHTML('beforeend', '<li class="active"><span>-</span>'+arrPageHistory[indexOfPage-1][item_num].name+'</li>');

					}else{ //Вложенные страницы
						arrPageHistory[indexOfPage] = arrPageHistory[indexOfPage - 1][item_num].level.slice();
						
						renderPage = arrPageHistory[indexOfPage].map((item,i) => 
							`<div class="checkbox">
								<input class="custom-checkbox" type="radio" name="${indexOfPage}" value="">
								<label>${item.name}</label>
							</div>`
						).join('');

						//Чистим активные классы у навигации
						for (let i = 0; i < quizNavLi.length; i++) {quizNavLi[i].classList.remove('active');}
						//Добавляем навигацию
						quizNav.insertAdjacentHTML('beforeend', '<li class="active"><span>-</span>'+arrPageHistory[indexOfPage-1][item_num].name+'</li>');

					}
				}else{ //Первая страница
					renderPage = arrPageHistory[indexOfPage].map((item,i) =>
						`<div class="checkbox">
							<input class="custom-checkbox" type="radio" name="${indexOfPage}" value="">
							<label>${item.name}</label>
						</div>`
					).join('');
				}
				
				//Добавляем HTML на страницу
				questionСontainer.innerHTML = renderPage;

				//Клик по чекбоксу
				let checkbox = quizForm.querySelectorAll('.checkbox input');
				for (let i = 0; i < checkbox.length; i++) {
					checkbox[i].addEventListener('click', function() {
						
						//анимация
						questionСontainer.classList.add('out');
						setTimeout(function(){

							//Увеличиваем индекс страницы
							indexOfPage = indexOfPage + 1;
							//Рендер вопросов
							render(i);
							//анимация
							questionСontainer.classList.remove('out');
						},500);

					}, false);
				}

				//Обновление контента
				if (quizForm.querySelector('.update')) {
					let btnUpdate = quizForm.querySelector('.update');
					let navLi = quizForm.querySelectorAll('.quiz-nav li');
					btnUpdate.addEventListener('click', function() {
						
						//анимация
						//questionСontainer.classList.add('out');
						setTimeout(function(){

							//Увеличиваем индекс страницы
							indexOfPage = 0;
							//Рендер вопросов
							render(0);
							//анимация
							//questionСontainer.classList.remove('out');

							//Чистим навигацию
							for (let i = 1; i < navLi.length; i++) {
								navLi[i].remove();
							}
							//Переключение на другую вкладку
							//setTimeout(function() {
								document.getElementById('quiz-callback').click();
							//}, 700);

						},500);

					}, false);
				}
			}

			//Первый старт
			render(indexOfPage);
		}
	}
	quiz();


	function calc (){
		
		//Марки бетона
		var price_input = document.getElementById('price_input');
      	var price;

      	//Кол-во м3
		var m3_input =  document.getElementById('m3_input');
      	var m3_result;

      	//Доставка
		var delivery_input = document.getElementById('delivery_input');
      	var delivery_result;
      	var delivery_result_from5;
      	var delivery_result_near5;
      	var delivery_value;

      	//Автобетононасос
      	var pumpe_input = document.getElementById('pump_input');
    	var pumpe_result;
    	document.getElementById('pump').value = 'Не требуется';
		
		//Выбор марки бетона
    	price_input.addEventListener('change', function(){
    		let str = this.options[this.selectedIndex].getAttribute('price');
    		str = str.replace(/\s+/g, '');
    		price = Number(str);
    		update();
    	});

  		//Событие выбора кол-ва м3
    	m3_input.oninput = function() {
    		update();
		};

		//Событие выбора адресса
    	delivery_input.addEventListener('change', function(){
			delivery_result_near5 = Number(this.options[this.selectedIndex].getAttribute('price'));
    		delivery_result_from5 = Number(this.options[this.selectedIndex].getAttribute('price5'));

    		delivery_value = this.options[this.selectedIndex].value;
			update();
    	});

    	pump_input.onchange = function() {
    		update();
	    };

	    function update(){
	    	if (price && price_input) {
				document.getElementById('m3_result').innerHTML = '<span>+</span>' + m3_input.value * price + ' ₽';
				//Почтовое поле
				document.getElementById('price').value = m3_input.value * price + ' ₽';
				document.getElementById('m3').value = m3_input.value + ' м³';
			}
			if (delivery_result_from5 && delivery_result_near5 ) {

				if (m3_input.value > 5) delivery_result = delivery_result_from5*m3_input.value;
				else delivery_result = delivery_result_near5;

				document.getElementById('delivery_result').innerHTML = '<span>+</span>' + delivery_result + ' ₽';
				//Почтовое поле
				document.getElementById('delivery').value = delivery_value + '(' + delivery_result + ' ₽)';
			}
			if (pump_input.checked) {
    			pumpe_result = 12500;
    			document.getElementById('pump_result').innerHTML = '<span>+</span>' + pumpe_result + ' ₽';
    			//Почтовое поле
    			document.getElementById('pump').value =  pumpe_result + ' ₽';
    		}else{
    			pumpe_result = '';
    			document.getElementById('pump_result').innerHTML = '';
    			//Почтовое поле
    			document.getElementById('pump').value = 'Не требуется';
    		}
			if (delivery_result && price && price_input) {
				document.getElementById('result').innerHTML = delivery_result + m3_input.value * price + ' ₽';
				document.getElementById('result_mobile').innerHTML = delivery_result + m3_input.value * price + ' ₽';
				//Почтовое поле
				document.getElementById('result_mail').value = delivery_result + m3_input.value * price + ' ₽';
			}
			if (delivery_result && price && price_input && pump_input.checked) {
				document.getElementById('result').innerHTML = delivery_result + m3_input.value * price + pumpe_result + ' ₽';
				document.getElementById('result_mobile').innerHTML = delivery_result + m3_input.value * price + pumpe_result + ' ₽';
				//Почтовое поле
				document.getElementById('result_mail').value = delivery_result + m3_input.value * price + pumpe_result + ' ₽';
			}
			
	    }
	}
	calc();