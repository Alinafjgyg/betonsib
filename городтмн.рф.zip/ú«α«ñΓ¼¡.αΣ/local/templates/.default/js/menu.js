'use strict';

//Menu

function menu() {

    //Добавить кнопку выпадающих подпунктов (для мобильной версии)
    var $linksLi = document.querySelectorAll('.links li');
    for (let i = 0; i < $linksLi.length; i++) {
        if ($linksLi[i].childNodes.length > 3) {
            $linksLi[i].insertAdjacentHTML('afterbegin', "<span class='sub-icon'></span>");
        }
    }

    function check() {

        var menu = document.querySelectorAll('.menu');
        for (let i = 0; i < menu.length; i++) {

            var more = menu[i].querySelector('.more');
            var vlinks = menu[i].querySelector('.links'); //все пункты
            var hlinks = menu[i].querySelector('.hidden-links'); //скрытые ссылки

            var hlinksLi = hlinks.querySelectorAll('li'); //скрытые ссылки
            if (hlinksLi) {
                for (let i = 0; i < hlinksLi.length; i++) {
                    vlinks.append(hlinksLi[i]);
                }
            }

            var vlinksLi = vlinks.querySelectorAll('li'); //видимые ссылки
            var container_vlinks = vlinks.offsetWidth; //ширина контейнера видимых пунктов
            var w_vlinks = 0; //ширина всех пунктов

            for (let i = 0; i < vlinksLi.length; i++) {
                w_vlinks = vlinksLi[i].offsetWidth + w_vlinks; //ширина всех пунктов
                if (container_vlinks < w_vlinks) {
                    hlinks.append(vlinksLi[i]);
                    more.classList.add('active');
                } else {
                    more.classList.remove('active');
                }

            }
        }
    }

    //Offcanvas Menu - open/close
    function offcanvasMenu() {

        var $body = document.querySelector('body'),
            $offcanvasMenu = document.querySelectorAll('.top-menu');

        for (let i = 0; i < $offcanvasMenu.length; i++) {

            let $offcanvasWrapper = $offcanvasMenu[i].querySelector('.menu'),
                $offcanvasOpen = $offcanvasMenu[i].querySelector('.offcanvas-open'),
                $offcanvasClose = $offcanvasMenu[i].querySelector('.offcanvas-close'),
                $subIcon = $offcanvasMenu[i].querySelectorAll('.links .sub-icon');

            //Открыть/закрыть подпункты
            for (let i = 0; i < $subIcon.length; i++) {

                $subIcon[i].addEventListener('click', function () {

                    $subIcon[i].classList.toggle('active');

                    var $li = $subIcon[i].closest('li'),
                        $ul = $li.querySelector('ul'),
                        display = getComputedStyle($ul).display;

                    if (display === 'none') {

                        $ul.style.display = 'block';
                        $ul.style.overflow = 'hidden';
                        $ul.style.transition = '0.5s';
                        $ul.style.height = 0;
                        $ul.style.height = $ul.scrollHeight + 'px';

                        setTimeout(function () {
                            $ul.removeAttribute('style');
                            $ul.style.display = 'block';
                        }, 300);

                    } else {
                        $ul.style.height = $ul.offsetHeight + 'px';
                        $ul.style.transition = '0.5s';
                        $ul.style.overflow = 'hidden';
                        setTimeout(function () {
                            $ul.style.height = 0
                        }, 1);

                        setTimeout(function () {
                            $ul.removeAttribute('style');
                        }, 300);
                    }

                }, false);
            }

            //Открыть меню
            $offcanvasOpen.addEventListener('click', function () {
                $body.style.overflow = 'hidden';
                openAnimation($offcanvasWrapper);
            }, false);

            //Закрыть меню
            $offcanvasClose.addEventListener('click', function () {
                $body.style.overflow = 'inherit';
                openAnimation($offcanvasWrapper);
            }, false);
        }

    }

    //Запуск
    $(window).resize(function () {
        check();
    });
    check();
    offcanvasMenu();
}

menu();

//Форма

var $formWrapper = document.querySelector('.form-wrapper'),
    $formOpen = document.querySelectorAll('.form-open'),
    $formClose = document.querySelector('.form-close');

//Открыть Форму
for (let i = 0; i < $formOpen.length; i++) {
    $formOpen[i].addEventListener('click', function () {
        $formWrapper.classList.toggle('active');
    }, false);
}

//Закрыть Форму
function formClose() {
    var $formClose = document.querySelector('.form-close');
    if ($formWrapper.classList.contains('active')) {
        $formWrapper.classList.remove('active');
    } else {
        $formWrapper.classList.remove('add');
    }
}

$formClose.addEventListener('click', function () {
    formClose();
}, false);
formClose();

//Анимация открытия/закрытия
function openAnimation(element) {

    var display = getComputedStyle(element).display,
        animationTime = 0.7,
        delayTime = animationTime * 1000,
        animation = String(animationTime) + 's ' + 'cubic-bezier(0.77, 0, 0.175, 1)';

    if (display === 'none') {

        element.style.height = 0;
        element.style.overflow = 'hidden';
        element.style.transition = animation;
        element.style.display = 'block';
        element.style.height = element.scrollHeight + 'px';

        setTimeout(function () {
            element.removeAttribute('style');
            element.style.display = 'block';
        }, delayTime);

    } else {

        element.style.height = element.offsetHeight + 'px';
        element.style.transition = animation;
        element.style.overflow = 'hidden';
        setTimeout(function () {
            element.style.height = 0
        }, 1);

        setTimeout(function () {
            element.removeAttribute('style');
        }, delayTime);
    }
}

//Сворачиваемый текст

function collapsibleText() {

    var $openBtnText = 'Развернуть',
        $closeBtnText = 'Свернуть',
        $text = document.querySelectorAll('.collapsible-text');

    for (let i = 0; i < $text.length; i++) {
        $text[i].insertAdjacentHTML('afterend', '<div class="more-text">' + $openBtnText + '</div>');
    }

    var $more = document.querySelectorAll('.more-text');

    for (let i = 0; i < $more.length; i++) {
        $more[i].addEventListener('click', function () {
            $text[i].classList.toggle('open');
            $more[i].classList.toggle('open');

            if ($text[i].classList.contains('open')) {
                $more[i].innerHTML = $closeBtnText;
            } else {
                $more[i].innerHTML = $openBtnText;
            }
        });
    }
}

collapsibleText();

//Вкладки

function tabs() {

    var $tabsContainer = document.querySelectorAll('.tabs-container');
    if ($tabsContainer) {
        for (let i = 0; i < $tabsContainer.length; i++) {

            let $tabLi = $tabsContainer[i].querySelectorAll('.tabs li'),
                $tabContent = $tabsContainer[i].querySelectorAll('.content'),
                $switch = $tabsContainer[i].querySelector('.tabs-switch span');

            $tabLi[0].classList.add('active');
            $tabContent[0].classList.add('active');

            for (let i = 0; i < $tabLi.length; i++) {

                $tabLi[i].addEventListener('click', function () {
                    removeClass();
                    $tabLi[i].classList.add('active');
                    $tabContent[i].classList.add('active');

                    //Переключатель
                    var position;
                    if (i != 0) {
                        position = 'calc(' + 100 / ($tabLi.length - 1) * i + '% - ' + 40 / ($tabLi.length - 1) * i + 'px)';
                    } else {
                        position = '0';
                    }
                    $switch.style.top = position;

                    //Прокуртка до вкладки
                    //scrollElement($tabContent[i]);

                }, false);
            }

            function removeClass() {
                for (let i = 0; i < $tabLi.length; i++) {
                    $tabLi[i].classList.remove('active');
                }
                for (let i = 0; i < $tabContent.length; i++) {
                    $tabContent[i].classList.remove('active');
                }
            }
        }
    }

}

tabs();

//Mask +7(___) ___-__-__
window.addEventListener("DOMContentLoaded", onDomContentLoaded);

function onDomContentLoaded() {
    setMask ();
    function setCursorPosition(pos, elem) {
        elem.focus();
        if (elem.setSelectionRange) elem.setSelectionRange(pos, pos);
        else if (elem.createTextRange) {
            var range = elem.createTextRange();
            range.collapse(true);
            range.moveEnd("character", pos);
            range.moveStart("character", pos);
            range.select()
        }
    }
    function mask(event) {
        var matrix = "+7 (___) ___-__-__",
            i = 0,
            def = matrix.replace(/\D/g, ""),
            val = this.value.replace(/\D/g, "");
        if (def.length >= val.length) val = def;
        this.value = matrix.replace(/./g, function (a) {
            return /[_\d]/.test(a) && i < val.length ? val.charAt(i++) : i >= val.length ? "" : a
        });
        if (event.type == "blur") {
            if (this.value.length == 2) this.value = ""
        } else setCursorPosition(this.value.length, this)
    };
    function setMask() {
        var input = document.querySelectorAll(".tel-mask");
        for (let i = 0; i < input.length; i++) {
            input[i].addEventListener("input", mask, false);
            input[i].addEventListener("focus", mask, false);
            input[i].addEventListener("blur", mask, false);
        }
    }
}


//Certificates
var $certHidden = document.querySelectorAll('.certificat-hidden');
var $certOpen = document.querySelector('.certificat-open');

if ($certOpen && $certHidden) {
    $certOpen.addEventListener('click', function () {
        for (let i = 0; i < $certHidden.length; i++) {
            $certHidden[i].classList.remove('certificat-hidden');
            $certHidden[i].classList.add('certificat-active');
            $certOpen.classList.add('hidden');
        }
    }, false);
}

//Замена прелоадера AJAX битрикс

var lastWait = [];
BX.showWait = function (node, msg) {
    node = BX(node) || document.body || document.documentElement;
    msg = msg || BX.message('JS_CORE_LOADING');

    var container_id = node.id || Math.random();

    var obMsg = node.bxmsg = document.body.appendChild(BX.create('DIV', {
        props: {
            id: 'wait_' + container_id,
            className: 'bx-core-waitwindow'
        },
        text: msg
    }));

    setTimeout(BX.delegate(_adjustWait, node), 10);

    $('.ajax_preloader').show();
    lastWait[lastWait.length] = obMsg;
    return obMsg;
};

BX.closeWait = function (node, obMsg) {
    $('.ajax_preloader').hide();
    if (node && !obMsg)
        obMsg = node.bxmsg;
    if (node && !obMsg && BX.hasClass(node, 'bx-core-waitwindow'))
        obMsg = node;
    if (node && !obMsg)
        obMsg = BX('wait_' + node.id);
    if (!obMsg)
        obMsg = lastWait.pop();

    if (obMsg && obMsg.parentNode) {
        for (var i = 0, len = lastWait.length; i < len; i++) {
            if (obMsg == lastWait[i]) {
                lastWait = BX.util.deleteFromArray(lastWait, i);
                break;
            }
        }

        obMsg.parentNode.removeChild(obMsg);
        if (node)
            node.bxmsg = null;
        BX.cleanNode(obMsg, true);
    }
};

function _adjustWait() {
    if (!this.bxmsg)
        return;

    var arContainerPos = BX.pos(this),
        div_top = arContainerPos.top;

    if (div_top < BX.GetDocElement().scrollTop)
        div_top = BX.GetDocElement().scrollTop + 5;

    this.bxmsg.style.top = (div_top + 5) + 'px';

    if (this == BX.GetDocElement()) {
        this.bxmsg.style.right = '5px';
    } else {
        this.bxmsg.style.left = (arContainerPos.right - this.bxmsg.offsetWidth - 5) + 'px';
    }
}
