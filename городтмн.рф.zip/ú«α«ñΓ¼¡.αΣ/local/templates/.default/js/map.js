	
	ymaps.ready(init);		
	function init() {
		var myMap = new ymaps.Map("map", {
			center: [57.142951, 65.615095],
			zoom: 10,
		}, {
			searchControlProvider: 'yandex#search'
		});
		//Отключение зума скроллом
		myMap.behaviors.disable('scrollZoom');
		myMap.controls.remove('geolocationControl');
		myMap.controls.remove('trafficControl');
		myMap.controls.remove('fullscreenControl');
		myMap.controls.remove('typeSelector');
		myMap.controls.remove('rulerControl');
		myMap.controls.remove('searchControl');
		// Вывод меток...
		var myPlacemark = new ymaps.Placemark([57.039918,65.728571], null,{
			iconLayout: 'default#image',
			iconImageHref: "/upload/img/contacts/placemark.svg",
			iconImageSize: [50, 50],
			iconImageOffset: [-25, -50]
		});
		myMap.geoObjects.add(myPlacemark);

		/*var myPlacemark = new ymaps.Placemark([57.178202, 65.465526], null,{
			iconLayout: 'default#image',
			iconImageHref: "/upload/img/contacts/placemark.svg",
			iconImageSize: [50, 50],
			iconImageOffset: [-25, -50]
		});
		myMap.geoObjects.add(myPlacemark);*/

		var myPlacemark = new ymaps.Placemark([57.123231639765, 65.6060116755196], null,{
			iconLayout: 'default#image',
			iconImageHref: "/upload/img/contacts/placemark.svg",
			iconImageSize: [50, 50],
			iconImageOffset: [-25, -50],
		});
		myMap.geoObjects.add(myPlacemark);

		// ул. Республики 211
		var myPlacemark = new ymaps.Placemark([57.142951, 65.615095], null,{
			iconLayout: 'default#image',
			iconImageHref: "/upload/img/contacts/placemark.svg",
			iconImageSize: [50, 50],
			iconImageOffset: [-25, -50],
		});
		myMap.geoObjects.add(myPlacemark);
	}
